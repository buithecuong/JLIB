
public class DemoLibrarian {

	String name;
	
	public DemoLibrarian()
	{
		this.name = "Simrandeep Kaur";
	}
	
	 public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	
	

}
